// Fill out your copyright notice in the Description page of Project Settings.

#include "spring_mass.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, spring_mass, "spring_mass" );
