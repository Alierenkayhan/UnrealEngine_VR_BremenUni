// Fill out your copyright notice in the Description page of Project Settings.

#include "spring_mass.h"
#include "Spring.h"

Spring::Spring(MassPoint* m1, MassPoint* m2, float length) :
m_m1(m1), m_m2(m2), 
m_spring_length_init(length),
m_stiffness(0.1),
m_damper(0.001)
{
}

Spring::~Spring()
{
}


void
Spring::Tick()
{
	FVector dist = m_m2->getCurrPos() - m_m1->getCurrPos();
	//dist.Normalize();
	r_ij = (m_m2->getCurrPos() - m_m1->getCurrPos()) / dist.Size();
	
	//FVector bla = (m_m2->getCurrPos() - m_m1->getCurrPos());
	//bla.Normalize();
	f_s = m_stiffness* r_ij* (dist.Size() - m_spring_length_init);
	f_d = -m_damper * FVector::DotProduct((m_m1->m_velocity - m_m2->m_velocity), r_ij) * r_ij;

	//f_d = (-1) * m_damper * ((m_m1->m_velocity - m_m2->m_velocity) * r_ij) * r_ij;

	force_m1 = f_s + f_d;// FVector(0, 0, 0);
	force_m2 = -1 * force_m1;
	if (!force_m1.ContainsNaN()) {
		m_m1->addForce(force_m1);
	}
	else {
		printf("test");
	}
	if (!force_m2.ContainsNaN()) {
		m_m2->addForce(force_m2);
	}
	else {
		printf("test");
	}
	//FIXME: Force
	//m_m1->m_currPos.Normalize()
	//FVector::Dist()
}
