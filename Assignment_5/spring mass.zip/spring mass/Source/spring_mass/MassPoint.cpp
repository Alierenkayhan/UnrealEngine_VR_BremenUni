// Fill out your copyright notice in the Description page of Project Settings.

#include "spring_mass.h"
#include "MassPoint.h"


MassPoint::MassPoint(uint32 vertex_id, bool movable, FVector pos) :
m_vertex_id(vertex_id),
m_currPos(pos),
m_force(FVector::ZeroVector),
m_velocity(FVector::ZeroVector),
m_movable(movable),
m_mass(0.00005)
{
	srand((unsigned)time(NULL));
}

void
MassPoint::updateGravity()
{
	// FIXME: gravity
	addForce(FVector(0, 0, (m_mass * 9.80665)));
	addForce(FVector(-((float)rand() / RAND_MAX)/100, -((float)rand() / RAND_MAX)/100, -((float)rand() / RAND_MAX))/100);

}

void 
MassPoint::updateCurPos(float deltaT)
{
	if (m_movable)
	{
		// FIXME: Verlet
		if (verlet) {
			if (m_lastPos.IsZero()) {
				m_lastPos = m_currPos;
				m_currPos = m_currPos + deltaT * m_velocity + (1 / 2) * pow(deltaT, 2) * ((1 / m_mass) * (m_force*(m_currPos*m_velocity)));
			}
			else {
				FVector tmpPos = m_currPos;
				m_currPos = m_currPos * 2 - m_lastPos + (m_force / m_mass) * pow(deltaT, 2);
				m_lastPos = tmpPos;
			}
		}
		else {
			m_velocity += m_force / m_mass * deltaT;
			m_currPos += m_velocity * deltaT;
		}
	}
	m_force = FVector::ZeroVector;
}

void
MassPoint::addForce(FVector f)
{
	if (m_movable)
	{	
		m_force += f;
	}
}

MassPoint::~MassPoint()
{
}
